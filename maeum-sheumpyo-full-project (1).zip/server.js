const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 3000;
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "12kb" }));
app.use(express.static("public"));
app.use("/api/", rateLimit({ windowMs: 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false }));

const CRISIS_RE = /(죽고\s*싶|자살|목숨을\s*끊|스스로\s*죽|죽어버리|살기\s*싫|끝내고\s*싶|자해|뛰어내리|약을\s*많이\s*먹|유서)/i;

const CRISIS_REPLY = `이 말을 꺼내기까지 얼마나 힘들었을지 마음이 쓰여요. 지금은 혼자 견디지 않았으면 해요.\n\n혹시 지금 당장 스스로를 다치게 할 위험이 있거나 구체적인 계획·수단이 곁에 있다면, 혼자 있지 말고 위험한 물건이나 장소에서 거리를 둔 뒤 가까운 믿을 만한 어른·친구에게 바로 알려 주세요. 급박한 위험은 112 또는 119, 자살예방 상담전화 109로 연락할 수 있어요.\n\n지금 당장 위험한 상황인지 먼저 확인하고 싶어요. 지금 혼자 있나요?`;

app.post("/api/chat", async (req, res) => {
  const message = typeof req.body.message === "string" ? req.body.message.trim() : "";
  if (!message || message.length > 4000) {
    return res.status(400).json({ error: "고민을 1~4000자 이내로 입력해 주세요." });
  }

  if (CRISIS_RE.test(message)) {
    return res.json({ reply: CRISIS_REPLY, crisis: true, mode: "safety" });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({
      error: "AI 연결이 아직 설정되지 않았어요. 운영자가 OPENAI_API_KEY를 서버 환경변수에 등록해야 해요.",
      setupRequired: true
    });
  }

  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const completion = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      temperature: 0.6,
      max_tokens: 500,
      messages: [
        {
          role: "system",
          content: `너는 한국어로 대화하는 '마음쉼표'의 공감형 지원 도우미다. 진단이나 치료를 제공한다고 말하지 않는다. 먼저 사용자의 감정을 인정하고, 들은 내용을 짧게 반영한 뒤 부담스럽지 않은 질문 하나나 작고 현실적인 다음 단계를 제안한다. 훈계하거나 낙관을 강요하지 않는다. 자살·자해 위험을 시사하면 비난 없이 안전을 확인하고, 즉시 위험하면 혼자 있지 말고 믿을 만한 사람에게 알리도록 권하며 한국의 109, 긴급 112·119를 안내한다. 자신이 전문 상담사나 응급 서비스인 척하지 않는다. 개인정보, 이름, 주소 등 식별정보를 요구하지 않는다. 한국어로 2~5문장 정도 답한다.`
        },
        { role: "user", content: message }
      ]
    });
    const reply = completion.choices?.[0]?.message?.content?.trim();
    if (!reply) throw new Error("Empty model response");
    return res.json({ reply, crisis: false, mode: "ai" });
  } catch (err) {
    console.error("AI request failed:", err.message);
    return res.status(502).json({ error: "지금은 답변을 가져오지 못했어요. 잠시 후 다시 시도하거나 아래 상담 자원을 이용해 주세요." });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`Maeum Sheumpyo listening on ${PORT}`));
