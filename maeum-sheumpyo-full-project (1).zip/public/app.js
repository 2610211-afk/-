const form = document.querySelector("#chat-form");
const input = document.querySelector("#message");
const send = document.querySelector("#send");
const charCount = document.querySelector("#char-count");
const conversation = document.querySelector("#conversation");
const messages = document.querySelector("#messages");
const moodButtons = [...document.querySelectorAll(".mood")];
const qrInput = document.querySelector("#site-url");
const qrTarget = document.querySelector("#qrcode");
const makeQr = document.querySelector("#make-qr");
const downloadQr = document.querySelector("#download-qr");

let selectedMood = "";
let qrInstance = null;

moodButtons.forEach(button => button.addEventListener("click", () => {
  moodButtons.forEach(b => b.classList.remove("selected"));
  button.classList.add("selected");
  selectedMood = button.dataset.mood;
  if (!input.value.trim()) input.placeholder = `${selectedMood}… 어떤 일이 있었는지 편하게 적어 주세요.`;
}));

input.addEventListener("input", () => {
  charCount.textContent = `${input.value.length} / 4000`;
});

function addBubble(text, type, label) {
  const bubble = document.createElement("div");
  bubble.className = `bubble ${type}`;
  if (label) {
    const tag = document.createElement("span");
    tag.className = "bubble-label";
    tag.textContent = label;
    bubble.appendChild(tag);
  }
  bubble.appendChild(document.createTextNode(text));
  messages.appendChild(bubble);
  conversation.classList.remove("hidden");
  bubble.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  const raw = input.value.trim();
  if (!raw) return;
  const message = selectedMood ? `[현재 감정: ${selectedMood}]\n${raw}` : raw;
  addBubble(raw, "user", "내 이야기");
  input.value = "";
  charCount.textContent = "0 / 4000";
  moodButtons.forEach(b => b.classList.remove("selected"));
  selectedMood = "";
  send.disabled = true;
  send.textContent = "답변을 준비하고 있어요…";
  const waiting = document.createElement("div");
  waiting.className = "bubble bot";
  waiting.textContent = "당신의 이야기를 천천히 읽고 있어요…";
  messages.appendChild(waiting);
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message })
    });
    const data = await response.json();
    waiting.remove();
    if (!response.ok) {
      addBubble(data.error || "답변을 불러오지 못했어요. 아래 도움 자원을 확인해 주세요.", "bot", "안내");
      if (data.setupRequired) addBubble("운영자가 호스팅 서비스의 환경변수 OPENAI_API_KEY에 유효한 API 키를 등록해야 실제 AI 답변이 작동해요. API 키를 웹페이지 코드에 직접 넣지 마세요.", "notice", "운영 설정 필요");
    } else {
      addBubble(data.reply, data.crisis ? "notice" : "bot", data.crisis ? "안전 안내" : "마음쉼표의 답변");
    }
  } catch (_error) {
    waiting.remove();
    addBubble("서버에 연결할 수 없어요. 인터넷 연결을 확인하고 잠시 후 다시 시도해 주세요. 급박한 위험이 있다면 112·119 또는 자살예방 상담전화 109로 연락해 주세요.", "notice", "연결 안내");
  } finally {
    send.disabled = false;
    send.innerHTML = '마음 나누기 <span>↗</span>';
    input.focus();
  }
});

document.querySelector("#clear").addEventListener("click", () => {
  messages.replaceChildren();
  conversation.classList.add("hidden");
  input.focus();
});

function currentSiteUrl() {
  return qrInput.value.trim() || (location.protocol.startsWith("http") ? location.origin : "");
}
makeQr.addEventListener("click", () => {
  const url = currentSiteUrl();
  if (!url || !/^https?:\/\//i.test(url)) {
    alert("먼저 https://로 시작하는 공개 사이트 주소를 입력해 주세요.");
    return;
  }
  if (typeof QRCode === "undefined") {
    alert("QR 라이브러리를 불러오지 못했어요. 인터넷 연결 후 새로고침해 주세요.");
    return;
  }
  qrTarget.replaceChildren();
  qrInstance = new QRCode(qrTarget, { text: url, width: 180, height: 180, colorDark: "#263b32", colorLight: "#ffffff", correctLevel: QRCode.CorrectLevel.H });
  downloadQr.disabled = false;
});
downloadQr.addEventListener("click", () => {
  const canvas = qrTarget.querySelector("canvas");
  const img = qrTarget.querySelector("img");
  const dataUrl = canvas ? canvas.toDataURL("image/png") : img?.src;
  if (!dataUrl) return;
  const a = document.createElement("a");
  a.href = dataUrl;
  a.download = "maeum-sheumpyo-qr.png";
  a.click();
});

if (location.protocol.startsWith("http")) qrInput.value = location.origin;
